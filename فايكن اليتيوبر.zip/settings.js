
const fs = require("fs");
const chalk = require("chalk")

global.BOT_TOKEN = "8764491605:AAEfq31gygWdcIBqSiPa8yDzC-5-P5jSHM4" // create bot here https://t.me/Botfather and get bot token
global.BOT_NAME = "- 𝑰𝑻𝑺 »Crash_Jo  CRASH BOT»࿅ 𓈪" //your bot name
global.OWNER_NAME = "https://t.me/Cc9cnw1 //your name with sign @
global.OWNER = ["https://t.me/Cc9cnw1", "https://t.me/Cc9cnw"] // Make sure the username is correct so that the special owner features can be used.
global.DEVELOPER = ["8764491605"] //developer telegram id to operate addprem delprem and listprem
global.pp = 'https://files.catbox.moe/ztcirt.png' //your bot pp


//approval
global.GROUP_ID = -5205731079; // Replace with your group ID
global.CHANNEL_ID =  -1003855063633; // Replace with your channel ID
global.GROUP_LINK = "https://t.me/+1KfE-C0fH_1iYmI0"; // Replace with your group link
global.CHANNEL_INVITE_LINK = "https://t.me/Cc9cnw12"; // Replace with your private channel invite link
global.WHATSAPP_LINK = "https://chat.whatsapp.com/BG1oI6mN0YbCGml98r5hCn?mode=gi_t"; // Replace with your group link
global.YOUTUBE_LINK = "https://youtube.com/@yosefsalah15?si=nj9IyznVg70F3mff"; // Replace with your youtube link
global.INSTAGRAM_LINK = "https://whatsapp.com/channel/0029VbCPAfL6RGJDDSAoSr1h"; // Replace with your ig link

global.owner = global.owner = ['+201092597220'] //owner whatsapp

const {
   english
} = require("./lib");
global.language = english
global.lang = language

let file = require.resolve(__filename)
fs.watchFile(file, () => {
fs.unwatchFile(file)
console.log(chalk.redBright(`Update ${__filename}`))
delete require.cache[file]
require(file)
})